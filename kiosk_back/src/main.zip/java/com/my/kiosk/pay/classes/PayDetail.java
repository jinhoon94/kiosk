package com.my.kiosk.pay.classes;

import lombok.Data;

@Data
public class PayDetail {
	private int id;
	private int pay_id;
	private int menu_id;
}
