package com.my.kiosk.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.my.kiosk.order.classes.OrderRequestDTO;
import com.my.kiosk.order.repository.StockOrderMapper;

@Service
public class StockOrderService {

	@Autowired
	StockOrderMapper mapper;

	 @Transactional
	public void insertOrder(OrderRequestDTO dto) {
		mapper.insertOrder(dto.getOut_id(), dto.getAmount());
		
	}
}
