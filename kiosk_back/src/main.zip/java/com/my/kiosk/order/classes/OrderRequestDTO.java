package com.my.kiosk.order.classes;

import lombok.Data;

@Data
public class OrderRequestDTO {
	private int out_id;
    private int amount;
}
