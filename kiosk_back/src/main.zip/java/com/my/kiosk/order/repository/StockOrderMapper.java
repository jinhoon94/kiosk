package com.my.kiosk.order.repository;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface StockOrderMapper {

	void insertOrder(@Param("out_id") int out_id, @Param("amount") int amount);

}
