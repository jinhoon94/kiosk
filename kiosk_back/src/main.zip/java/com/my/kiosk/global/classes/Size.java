package com.my.kiosk.global.classes;

import lombok.Data;

@Data
public class Size {
	private int id;
	private String size;
	private int price;
}
