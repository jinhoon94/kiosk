package com.my.kiosk.stock.classes;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Place_SellDTO {
	public int place_id;
	public boolean selling;
}
